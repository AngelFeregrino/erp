-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: erp
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atributos_pieza`
--

DROP TABLE IF EXISTS `atributos_pieza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atributos_pieza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pieza_id` int(11) NOT NULL,
  `nombre_atributo` varchar(50) NOT NULL,
  `unidad` varchar(20) DEFAULT NULL,
  `valor_predeterminado` decimal(10,2) DEFAULT NULL,
  `tolerancia` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pieza_id` (`pieza_id`),
  CONSTRAINT `atributos_pieza_ibfk_1` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atributos_pieza`
--

LOCK TABLES `atributos_pieza` WRITE;
/*!40000 ALTER TABLE `atributos_pieza` DISABLE KEYS */;
INSERT INTO `atributos_pieza` VALUES (1,1,'Peso','gr',8.50,0.05),(2,1,'Altura','mm',25.40,0.10),(3,1,'Altura de Flange','mm',1.50,0.05),(4,1,'Diámetro Interior','mm',7.93,0.03),(5,1,'Diámetro Exterior','mm',11.20,0.02),(6,1,'Diámetro Flange','mm',15.29,0.01),(7,1,'Densidad','gr/cm3',6.23,0.01),(8,2,'Peso','gr',7.10,0.20),(9,2,'Altura','mm',16.00,0.10),(10,2,'Diámetro Interior','mm',6.43,0.03),(11,2,'Diámetro Exterior','mm',12.25,0.01),(12,2,'Diámetro Estrella','mm',8.90,0.05),(13,2,'Altura Interior','mm',1.42,0.07),(14,2,'Densidad','gr/cm3',6.40,0.10),(15,3,'Peso','gr',1.20,0.01),(16,3,'Altura','mm',2.54,0.04),(17,3,'Diámetro interior','mm',7.49,0.01),(18,3,'Diámetro exterior','mm',11.99,0.03),(19,3,'Densidad ','gr/cm3',0.18,0.00),(20,4,'Peso','gr',48.50,1.00),(21,4,'Altura','mm',11.80,0.05),(22,4,'Diámetro interior ','mm',32.25,0.05),(23,4,'Diámetro exterior dientes ','mm',50.10,0.10),(24,4,'Diámetro exterior ','mm',42.08,0.07),(25,5,'Peso','gr',2.01,0.02),(26,5,'Altura','mm',7.83,0.05),(27,5,'Diámetro interior','mm',6.98,0.03),(28,5,'Diámetro exterior','mm',10.08,0.01),(29,5,'Densidad','gr/cm3',6.69,0.09),(30,6,'Peso','gr',7.82,0.17),(31,6,'Altura','mm',10.42,0.07),(32,6,'Diámetro Interior','mm',12.58,0.03),(33,6,'Diámetro Exterior','mm',15.97,0.04),(34,6,'Diámetro Flange','mm',22.08,0.05),(35,6,'Flange','mm',2.90,0.05),(36,6,'Densidad','gr/cm3',6.20,0.10),(37,7,'Peso','gr',3.73,0.07),(38,7,'Altura','mm',13.68,0.07),(39,7,'Diámetro interior','mm',6.42,0.02),(40,7,'Diámetro exterior','mm',9.65,0.01),(41,7,'Diámetro Flange','mm',10.90,0.05),(42,7,'Flange','mm',2.60,0.08),(43,7,'Densidad','gr/cm3',6.00,0.20),(44,8,'Peso','gr',0.67,0.01),(45,8,'Altura','mm',1.57,0.03),(46,8,'Diámetro interior','mm',8.64,0.04),(47,8,'Diámetro exterior','mm',12.73,0.03),(48,8,'Densidad','gr/cm3',0.10,0.10),(49,9,'Peso','gr',18.35,0.15),(50,9,'Altura','mm',12.75,0.10),(51,9,'Diámetro interior','mm',15.98,0.05),(52,9,'Diámetro Exterior','mm',23.91,0.03),(53,10,'Peso','gr',8.60,0.10),(54,10,'Altura','mm',9.68,0.05),(55,10,'Diámetro interior','mm',10.25,0.05),(56,10,'Diámetro exterior','mm',17.55,0.05),(57,10,'Alt','mm',4.60,0.05),(58,11,'Peso','gr',116.00,2.00),(59,11,'Altura','mm',11.80,0.10),(60,11,'Diámetro interior','mm',7.95,0.05),(61,11,'Diámetro exterior','mm',59.54,0.54),(62,12,'Peso','gr',24.10,1.00),(63,12,'Altura','mm',12.75,0.05),(64,12,'Diámetro interior','mm',15.99,0.04),(65,12,'Diámetro exterior','mm',25.33,0.02),(66,13,'Peso','gr',2.37,0.03),(67,13,'Altura','mm',2.54,0.04),(68,13,'Diámetro interior','mm',11.58,0.02),(69,13,'Diámetro exterior','mm',17.68,0.02),(70,13,'Densidad','gr/cm3',6.72,0.06),(71,14,'Peso','gr',16.50,0.50),(72,14,'Altura','mm',25.46,0.06),(73,14,'Diámetro Interior','mm',19.03,0.02),(74,14,'Diámetro exterior','mm',22.19,0.03),(75,14,'Densidad','gr/cm3',6.40,0.00),(76,15,'Peso','gr',2.31,0.02),(77,15,'Altura','mm',7.36,0.02),(78,15,'Diámetro Interior ','mm',4.18,0.01),(79,15,'Diámetro exterior','mm',9.15,0.05),(80,16,'Peso','gr',36.55,0.25),(81,16,'Altura','mm',23.50,0.05),(82,16,'Diámetro Interior','mm',12.84,0.02),(83,16,'Diámetro exterior','mm',22.18,0.01);
/*!40000 ALTER TABLE `atributos_pieza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capturas_hora`
--

DROP TABLE IF EXISTS `capturas_hora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capturas_hora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `prensa_id` int(11) NOT NULL,
  `pieza_id` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `observaciones_op` text DEFAULT NULL,
  `firma_operador` varchar(100) DEFAULT NULL,
  `estado` enum('pendiente','cerrada') DEFAULT 'pendiente',
  PRIMARY KEY (`id`),
  KEY `orden_id` (`orden_id`),
  KEY `prensa_id` (`prensa_id`),
  KEY `pieza_id` (`pieza_id`),
  CONSTRAINT `capturas_hora_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes_produccion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `capturas_hora_ibfk_2` FOREIGN KEY (`prensa_id`) REFERENCES `prensas` (`id`),
  CONSTRAINT `capturas_hora_ibfk_3` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capturas_hora`
--

LOCK TABLES `capturas_hora` WRITE;
/*!40000 ALTER TABLE `capturas_hora` DISABLE KEYS */;
INSERT INTO `capturas_hora` VALUES (1,1,'2025-11-27',3,3,'13:00:00','14:00:00',NULL,NULL,NULL,'cerrada'),(2,1,'2025-11-27',3,3,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(3,1,'2025-11-27',3,3,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(4,2,'2025-11-27',4,8,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(5,2,'2025-11-27',4,8,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(6,3,'2025-11-27',1,3,'15:00:00','16:00:00',NULL,'SE ROMPE EL DETALLE','uziel jaret','cerrada'),(7,4,'2025-11-28',3,3,'08:00:00','09:00:00',NULL,'','uziel jaret','cerrada'),(8,4,'2025-11-28',3,3,'09:00:00','10:00:00',NULL,'','uziel jaret','cerrada'),(9,4,'2025-11-28',3,3,'10:00:00','11:00:00',NULL,'','uziel jaret','cerrada'),(10,4,'2025-11-28',3,3,'11:00:00','12:00:00',NULL,'','uziel jaret','cerrada'),(11,4,'2025-11-28',3,3,'12:00:00','13:00:00',NULL,'','uziel jaret','cerrada'),(12,4,'2025-11-28',3,3,'13:00:00','14:00:00',NULL,'','uziel jaret','cerrada'),(13,4,'2025-11-28',3,3,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(14,4,'2025-11-28',3,3,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(15,5,'2025-11-28',4,8,'08:00:00','09:00:00',NULL,'','uziel jaret','cerrada'),(16,5,'2025-11-28',4,8,'09:00:00','10:00:00',NULL,'','uziel jaret','cerrada'),(17,5,'2025-11-28',4,8,'10:00:00','11:00:00',NULL,'','uziel jaret','cerrada'),(18,5,'2025-11-28',4,8,'11:00:00','12:00:00',NULL,'','uziel jaret','cerrada'),(19,5,'2025-11-28',4,8,'12:00:00','13:00:00',NULL,'','uziel jaret','cerrada'),(20,5,'2025-11-28',4,8,'13:00:00','14:00:00',NULL,'','uziel jaret','cerrada'),(21,5,'2025-11-28',4,8,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(22,5,'2025-11-28',4,8,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(23,6,'2025-11-29',3,3,'08:00:00','09:00:00',NULL,'','lupe','cerrada'),(24,6,'2025-11-29',3,3,'09:00:00','10:00:00',NULL,'','lupe','cerrada'),(25,6,'2025-11-29',3,3,'10:00:00','11:00:00',NULL,'','lupe','cerrada'),(26,6,'2025-11-29',3,3,'11:00:00','12:00:00',NULL,'','lupe','cerrada'),(27,6,'2025-11-29',3,3,'12:00:00','13:00:00',NULL,'','lupe','cerrada'),(28,6,'2025-11-29',3,3,'13:00:00','14:00:00',NULL,NULL,NULL,'cerrada'),(29,6,'2025-11-29',3,3,'14:00:00','15:00:00',NULL,NULL,NULL,'cerrada'),(30,6,'2025-11-29',3,3,'15:00:00','16:00:00',NULL,NULL,NULL,'cerrada'),(39,8,'2025-11-29',4,8,'08:00:00','09:00:00',NULL,'','lupe','cerrada'),(40,8,'2025-11-29',4,8,'09:00:00','10:00:00',NULL,'','lupe','cerrada'),(41,8,'2025-11-29',4,8,'10:00:00','11:00:00',NULL,'','lupe','cerrada'),(42,8,'2025-11-29',4,8,'11:00:00','12:00:00',NULL,'','lupe','cerrada'),(43,8,'2025-11-29',4,8,'12:00:00','13:00:00',NULL,'','lupe','cerrada'),(44,8,'2025-11-29',4,8,'13:00:00','14:00:00',NULL,NULL,NULL,'cerrada'),(45,8,'2025-11-29',4,8,'14:00:00','15:00:00',NULL,NULL,NULL,'cerrada'),(46,8,'2025-11-29',4,8,'15:00:00','16:00:00',NULL,NULL,NULL,'cerrada'),(47,9,'2025-12-01',3,3,'11:00:00','12:00:00',NULL,'','uziel jaret','cerrada'),(48,9,'2025-12-01',3,3,'12:00:00','13:00:00',NULL,NULL,NULL,'cerrada'),(49,9,'2025-12-01',3,3,'13:00:00','14:00:00',NULL,'','uziel jaret','cerrada'),(50,9,'2025-12-01',3,3,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(51,9,'2025-12-01',3,3,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(52,10,'2025-12-01',4,8,'11:00:00','12:00:00',NULL,'','uziel jaret','cerrada'),(53,10,'2025-12-01',4,8,'12:00:00','13:00:00',NULL,NULL,NULL,'cerrada'),(54,10,'2025-12-01',4,8,'13:00:00','14:00:00',NULL,'','uziel jaret','cerrada'),(55,10,'2025-12-01',4,8,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(56,10,'2025-12-01',4,8,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(57,11,'2025-12-02',3,3,'10:00:00','11:00:00',NULL,'','Eduardo','cerrada'),(58,11,'2025-12-02',3,3,'11:00:00','12:00:00',NULL,'','Eduardo','cerrada'),(59,11,'2025-12-02',3,3,'12:00:00','13:00:00',NULL,'','Eduardo','cerrada'),(60,11,'2025-12-02',3,3,'13:00:00','14:00:00',NULL,'','Eduardo','cerrada'),(61,11,'2025-12-02',3,3,'14:00:00','15:00:00',NULL,'','Eduardo','cerrada'),(62,11,'2025-12-02',3,3,'15:00:00','16:00:00',NULL,'','Eduardo','cerrada'),(63,12,'2025-12-02',3,3,'16:00:00','17:00:00',NULL,'','uziel jaret','cerrada'),(64,12,'2025-12-02',3,3,'17:00:00','18:00:00',NULL,'','uziel jaret','cerrada'),(65,12,'2025-12-02',3,3,'18:00:00','19:00:00',NULL,'','uziel jaret','cerrada'),(66,12,'2025-12-02',3,3,'19:00:00','20:00:00',NULL,NULL,NULL,'cerrada'),(67,12,'2025-12-02',3,3,'20:00:00','21:00:00',NULL,NULL,NULL,'cerrada'),(68,12,'2025-12-02',3,3,'21:00:00','22:00:00',NULL,NULL,NULL,'cerrada'),(69,12,'2025-12-02',3,3,'22:00:00','23:00:00',NULL,'se paro prensa a las 9 y se volvio a prender a las 10:30 y registros anteriores no se hizo por zona horaria error (YA ARREGLADO)','lupe','cerrada'),(70,12,'2025-12-02',3,3,'23:00:00','00:00:00',NULL,'','lupe','cerrada'),(71,13,'2025-12-03',3,3,'00:00:00','01:00:00',NULL,'','lupe','cerrada'),(72,13,'2025-12-03',3,3,'01:00:00','02:00:00',NULL,'','lupe','cerrada'),(73,13,'2025-12-03',3,3,'02:00:00','03:00:00',NULL,'','lupe','cerrada'),(74,13,'2025-12-03',3,3,'03:00:00','04:00:00',NULL,'','lupe','cerrada'),(75,13,'2025-12-03',3,3,'04:00:00','05:00:00',NULL,'','lupe','cerrada'),(76,13,'2025-12-03',3,3,'05:00:00','06:00:00',NULL,NULL,NULL,'cerrada'),(77,13,'2025-12-03',3,3,'06:00:00','07:00:00',NULL,'','nancy','cerrada'),(78,13,'2025-12-03',3,3,'07:00:00','08:00:00',NULL,'','Nancy','cerrada'),(87,15,'2025-12-03',3,3,'08:00:00','09:00:00',NULL,'','Nancy','cerrada'),(88,15,'2025-12-03',3,3,'09:00:00','10:00:00',NULL,'','Nancy','cerrada'),(89,15,'2025-12-03',3,3,'10:00:00','11:00:00',NULL,'','Nancy','cerrada'),(90,15,'2025-12-03',3,3,'11:00:00','12:00:00',NULL,'','Nancy','cerrada'),(91,15,'2025-12-03',3,3,'12:00:00','13:00:00',NULL,'','Nancy','cerrada'),(92,15,'2025-12-03',3,3,'13:00:00','14:00:00',NULL,'','uziel jaret','cerrada'),(93,15,'2025-12-03',3,3,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(94,15,'2025-12-03',3,3,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(95,17,'2025-12-03',3,3,'16:00:00','17:00:00',NULL,'','uziel jaret','cerrada'),(96,17,'2025-12-03',3,3,'17:00:00','18:00:00',NULL,'','uziel jaret','cerrada'),(97,17,'2025-12-03',3,3,'18:00:00','19:00:00',NULL,'','uziel jaret','cerrada'),(98,17,'2025-12-03',3,3,'19:00:00','20:00:00',NULL,'','uziel jaret','cerrada'),(99,17,'2025-12-03',3,3,'20:00:00','21:00:00',NULL,'','uziel jaret','cerrada'),(100,17,'2025-12-03',3,3,'21:00:00','22:00:00',NULL,NULL,NULL,'cerrada'),(101,17,'2025-12-03',3,3,'22:00:00','23:00:00',NULL,'','lupe','cerrada'),(102,17,'2025-12-03',3,3,'23:00:00','00:00:00',NULL,'','lupe','cerrada'),(103,18,'2025-12-04',3,3,'00:00:00','01:00:00',NULL,'','lupe','cerrada'),(104,18,'2025-12-04',3,3,'01:00:00','02:00:00',NULL,'','lupe','cerrada'),(105,18,'2025-12-04',3,3,'02:00:00','03:00:00',NULL,'','lupe','cerrada'),(106,18,'2025-12-04',3,3,'03:00:00','04:00:00',NULL,'','lupe','cerrada'),(107,18,'2025-12-04',3,3,'04:00:00','05:00:00',NULL,'','lupe','cerrada'),(108,18,'2025-12-04',3,3,'05:00:00','06:00:00',NULL,'','lupe','cerrada'),(109,18,'2025-12-04',3,3,'06:00:00','07:00:00',NULL,'','Nancy','cerrada'),(110,18,'2025-12-04',3,3,'07:00:00','08:00:00',NULL,'se paro prensa a las 7','Nancy','cerrada'),(111,19,'2025-12-04',3,3,'08:00:00','09:00:00',NULL,'','Nancy','cerrada'),(112,19,'2025-12-04',3,3,'09:00:00','10:00:00',NULL,'','Nancy','cerrada'),(113,19,'2025-12-04',3,3,'10:00:00','11:00:00',NULL,'','Nancy','cerrada'),(114,19,'2025-12-04',3,3,'11:00:00','12:00:00',NULL,'se para prensa a las 11','Luis','cerrada'),(115,19,'2025-12-04',3,3,'12:00:00','13:00:00',NULL,NULL,NULL,'cerrada'),(116,19,'2025-12-04',3,3,'13:00:00','14:00:00',NULL,'','uziel jaret','cerrada'),(117,19,'2025-12-04',3,3,'14:00:00','15:00:00',NULL,'','uziel jaret','cerrada'),(118,19,'2025-12-04',3,3,'15:00:00','16:00:00',NULL,'','uziel jaret','cerrada'),(126,21,'2025-12-04',3,3,'16:00:00','17:00:00',NULL,'','uziel jaret','cerrada'),(127,21,'2025-12-04',3,3,'17:00:00','18:00:00',NULL,'','uziel jaret','cerrada'),(128,21,'2025-12-04',3,3,'18:00:00','19:00:00',NULL,'','uziel jaret','cerrada'),(129,21,'2025-12-04',3,3,'19:00:00','20:00:00',NULL,'','uziel jaret','cerrada'),(130,21,'2025-12-04',3,3,'20:00:00','21:00:00',NULL,'','uziel jaret','cerrada'),(131,21,'2025-12-04',3,3,'21:00:00','22:00:00',NULL,'','BETO','cerrada'),(132,21,'2025-12-04',3,3,'22:00:00','23:00:00',NULL,'','lupe','cerrada'),(133,21,'2025-12-04',3,3,'23:00:00','00:00:00',NULL,'','lupe','cerrada'),(134,22,'2025-12-04',4,5,'18:00:00','19:00:00',NULL,'','uziel jaret','cerrada'),(135,22,'2025-12-04',4,5,'19:00:00','20:00:00',NULL,'','uziel jaret','cerrada'),(136,22,'2025-12-04',4,5,'20:00:00','21:00:00',NULL,'','uziel jaret','cerrada'),(137,22,'2025-12-04',4,5,'21:00:00','22:00:00',NULL,'','BETO','cerrada'),(138,22,'2025-12-04',4,5,'22:00:00','23:00:00',NULL,'','lupe','cerrada'),(139,22,'2025-12-04',4,5,'23:00:00','00:00:00',NULL,NULL,NULL,'cerrada'),(140,23,'2025-12-05',3,3,'00:00:00','01:00:00',NULL,'','lupe','cerrada'),(141,23,'2025-12-05',3,3,'01:00:00','02:00:00',NULL,'','lupe','cerrada'),(142,23,'2025-12-05',3,3,'02:00:00','03:00:00',NULL,'','lupe','cerrada'),(143,23,'2025-12-05',3,3,'03:00:00','04:00:00',NULL,'','lupe','cerrada'),(144,23,'2025-12-05',3,3,'04:00:00','05:00:00',NULL,'','lupe','cerrada'),(145,23,'2025-12-05',3,3,'05:00:00','06:00:00',NULL,'','lupe','cerrada'),(146,23,'2025-12-05',3,3,'06:00:00','07:00:00',NULL,'','Nancy','cerrada'),(147,23,'2025-12-05',3,3,'07:00:00','08:00:00',NULL,'','Nancy','cerrada'),(148,24,'2025-12-05',4,5,'00:00:00','01:00:00',NULL,'','lupe','cerrada'),(149,24,'2025-12-05',4,5,'01:00:00','02:00:00',NULL,'','lupe','cerrada'),(150,24,'2025-12-05',4,5,'02:00:00','03:00:00',NULL,'','lupe','cerrada'),(151,24,'2025-12-05',4,5,'03:00:00','04:00:00',NULL,'','lupe','cerrada'),(152,24,'2025-12-05',4,5,'04:00:00','05:00:00',NULL,'','lupe','cerrada'),(153,24,'2025-12-05',4,5,'05:00:00','06:00:00',NULL,'','lupe','cerrada'),(154,24,'2025-12-05',4,5,'06:00:00','07:00:00',NULL,'','Nancy','cerrada'),(155,24,'2025-12-05',4,5,'07:00:00','08:00:00',NULL,'','Nancy','cerrada'),(156,25,'2025-12-05',3,3,'08:00:00','09:00:00',NULL,'','Nancy','cerrada'),(157,25,'2025-12-05',3,3,'09:00:00','10:00:00',NULL,'','Nancy','cerrada'),(158,25,'2025-12-05',3,3,'10:00:00','11:00:00',NULL,'','Nancy','cerrada'),(159,25,'2025-12-05',3,3,'11:00:00','12:00:00',NULL,'','Nancy','cerrada'),(160,25,'2025-12-05',3,3,'12:00:00','13:00:00',NULL,'','Nancy','cerrada'),(161,25,'2025-12-05',3,3,'13:00:00','14:00:00',NULL,'','Nancy','cerrada'),(162,25,'2025-12-05',3,3,'14:00:00','15:00:00',NULL,'','BETO','cerrada'),(163,25,'2025-12-05',3,3,'15:00:00','16:00:00',NULL,'','BETO','cerrada'),(164,26,'2025-12-05',4,5,'08:00:00','09:00:00',NULL,'SE ACABO POLVO','Nancy','cerrada'),(165,26,'2025-12-05',4,5,'09:00:00','10:00:00',NULL,'','Nancy','cerrada'),(166,26,'2025-12-05',4,5,'10:00:00','11:00:00',NULL,'','Nancy','cerrada'),(167,26,'2025-12-05',4,5,'11:00:00','12:00:00',NULL,'','Nancy','cerrada'),(168,26,'2025-12-05',4,5,'12:00:00','13:00:00',NULL,'','Nancy','cerrada'),(169,26,'2025-12-05',4,5,'13:00:00','14:00:00',NULL,'SE ACABO POLVO','Nancy','cerrada'),(170,26,'2025-12-05',4,5,'14:00:00','15:00:00',NULL,'','BETO','cerrada'),(171,26,'2025-12-05',4,5,'15:00:00','16:00:00',NULL,'','BETO','cerrada'),(172,27,'2025-12-05',4,5,'22:00:00','23:00:00',NULL,'','lupe','cerrada'),(173,27,'2025-12-05',4,5,'23:00:00','00:00:00',NULL,'','lupe','cerrada'),(174,28,'2025-12-05',3,3,'22:00:00','23:00:00',NULL,'','lupe','cerrada'),(175,28,'2025-12-05',3,3,'23:00:00','00:00:00',NULL,NULL,NULL,'cerrada'),(176,29,'2025-12-06',4,5,'00:00:00','01:00:00',NULL,'','Luis Angel','cerrada'),(177,29,'2025-12-06',4,5,'01:00:00','02:00:00',NULL,'','Luis Angel','cerrada'),(178,29,'2025-12-06',4,5,'02:00:00','03:00:00',NULL,'','Luis Angel','cerrada'),(179,29,'2025-12-06',4,5,'03:00:00','04:00:00',NULL,'','Luis Angel','cerrada'),(180,29,'2025-12-06',4,5,'04:00:00','05:00:00',NULL,'','Luis Angel','cerrada'),(181,29,'2025-12-06',4,5,'05:00:00','06:00:00',NULL,'','Luis Angel','cerrada'),(182,29,'2025-12-06',4,5,'06:00:00','07:00:00',NULL,'','luis','cerrada'),(183,29,'2025-12-06',4,5,'07:00:00','08:00:00',NULL,'','Luis','cerrada'),(184,30,'2025-12-06',3,3,'00:00:00','01:00:00',NULL,'','Luis Angel','cerrada'),(185,30,'2025-12-06',3,3,'01:00:00','02:00:00',NULL,'','Luis Angel','cerrada'),(186,30,'2025-12-06',3,3,'02:00:00','03:00:00',NULL,'','Luis Angel','cerrada'),(187,30,'2025-12-06',3,3,'03:00:00','04:00:00',NULL,'','Luis Angel','cerrada'),(188,30,'2025-12-06',3,3,'04:00:00','05:00:00',NULL,'','Luis Angel','cerrada'),(189,30,'2025-12-06',3,3,'05:00:00','06:00:00',NULL,'','Luis Angel','cerrada'),(190,30,'2025-12-06',3,3,'06:00:00','07:00:00',NULL,'','luis','cerrada'),(191,30,'2025-12-06',3,3,'07:00:00','08:00:00',NULL,'se para prena fin de pensado','Luis Angel','cerrada');
/*!40000 ALTER TABLE `capturas_hora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_produccion`
--

DROP TABLE IF EXISTS `ordenes_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordenes_produccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_orden` varchar(20) NOT NULL,
  `pieza_id` int(11) NOT NULL,
  `numero_lote` varchar(50) DEFAULT NULL,
  `cantidad_total_lote` int(11) DEFAULT NULL,
  `prensa_id` int(11) DEFAULT NULL,
  `operador_asignado` varchar(100) DEFAULT NULL,
  `equipo_asignado` varchar(100) DEFAULT NULL,
  `firma_responsable` varchar(100) DEFAULT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_cierre` date DEFAULT NULL,
  `estado` enum('abierta','cerrada') DEFAULT 'abierta',
  `admin_id` int(11) NOT NULL,
  `cantidad_inicio` bigint(20) NOT NULL DEFAULT 0,
  `cantidad_final` bigint(20) DEFAULT NULL,
  `total_producida` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `pieza_id` (`pieza_id`),
  KEY `prensa_id` (`prensa_id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `ordenes_produccion_ibfk_1` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`),
  CONSTRAINT `ordenes_produccion_ibfk_2` FOREIGN KEY (`prensa_id`) REFERENCES `prensas` (`id`),
  CONSTRAINT `ordenes_produccion_ibfk_3` FOREIGN KEY (`admin_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_produccion`
--

LOCK TABLES `ordenes_produccion` WRITE;
/*!40000 ALTER TABLE `ordenes_produccion` DISABLE KEYS */;
INSERT INTO `ordenes_produccion` VALUES (1,'52',3,'2025-11-27-34',NULL,3,'uziel jaret','SQ-MIC-01','nancy','2025-11-27','2025-11-27','cerrada',1,296183,304455,8272),(2,'52',8,'2025-11-27-01',NULL,4,'uziel jaret','SQ-MIC-01','nancy','2025-11-27','2025-11-27','cerrada',1,0,5296,5296),(3,'52',3,'2025-11-27-34',NULL,1,'uziel jaret','SQ-MIC-01','nancy','2025-11-27','2025-11-27','cerrada',1,403705,412387,8682),(4,'52',3,'2025-11-28-35',NULL,3,'uziel jaret','SQ-MIC-01','nancy','2025-11-28','2025-11-28','cerrada',1,304455,313375,8920),(5,'52',8,'2025-11-28-02',NULL,4,'uziel jaret','SQ-MIC-01','nancy','2025-11-28','2025-11-28','cerrada',1,5296,13370,8074),(6,'52',3,'2025-11-29-36',NULL,3,'lupe','SQ-MIC-01','Luis A.','2025-11-29','2025-11-29','cerrada',1,313375,319946,6571),(8,'52',8,'2025-11-29-03',NULL,4,'lupe','SQ-MIC-01','Luis A.','2025-11-29','2025-11-29','cerrada',1,13370,19571,6201),(9,'52',3,'2025-12-01-37',NULL,3,'uziel jaret','SQ-MIC-01','Eduardo','2025-12-01','2025-12-01','cerrada',1,319946,324971,5025),(10,'52',8,'2025-12-01-04',NULL,4,'uziel jaret','vernier','Eduardo','2025-12-01','2025-12-01','cerrada',1,19571,24065,4494),(11,'52',3,'2025-12-02-38',NULL,3,'Eduardo','SQ-MIC-01','nancy','2025-12-02','2025-12-02','cerrada',1,324971,331402,6431),(12,'52',3,'2025-12-02-37',NULL,3,'uziel jaret','SQ-MIC-01','Luis A.','2025-12-02','2025-12-03','cerrada',1,331402,337882,6480),(13,'52',3,'2025-12-03-39',NULL,3,'lupe','SQ-MIC-01','nancy','2025-12-03','2025-12-03','cerrada',1,337882,346679,8797),(15,'52',3,'2025-12-03-39',NULL,3,'Nancy','SQ-MIC-01','Eduardo','2025-12-03','2025-12-03','cerrada',1,346679,355850,9171),(17,'52',3,'2025-12-03-39',NULL,3,'uziel jaret','SQ-MIC-01','Luis A.','2025-12-03','2025-12-04','cerrada',1,355850,365880,10030),(18,'52',3,'2025-12-04-40',NULL,3,'lupe','SQ-MIC-01','nancy','2025-12-04','2025-12-04','cerrada',1,365880,373711,7831),(19,'52',3,'2025-12-04-40',NULL,3,'uziel jaret','SQ-MIC-01','nancy','2025-12-04','2025-12-04','cerrada',1,373711,380184,6473),(21,'52',3,'2025-12-04-40',NULL,3,'uziel jaret','SQ-MIC-01','Eduardo','2025-12-04','2025-12-05','cerrada',1,380184,390241,10057),(22,'52',5,'2025-12-04-01',NULL,4,'uziel jaret','SQ-MIC-01','Eduardo','2025-12-04','2025-12-05','cerrada',1,0,7439,7439),(23,'52',3,'2025-12-05-40',NULL,3,'lupe','SQ-MIC-01','nancy','2025-12-05','2025-12-05','cerrada',1,390241,399417,9176),(24,'52',5,'2025-12-05-01',NULL,4,'lupe','SQ-MIC-01','nancy','2025-12-05','2025-12-05','cerrada',1,7439,16612,9173),(25,'52',3,'2025-12-05-41',NULL,3,'Nancy','SQ-MIC-01','Luis A.','2025-12-05','2025-12-05','cerrada',1,399417,416940,17523),(26,'52',5,'2025-12-05-02',NULL,4,'Nancy','SQ-MIC-01','Luis A.','2025-12-05','2025-12-05','cerrada',1,16612,30205,13593),(27,'52',5,'2025-12-05-03',NULL,4,'lupe','SQ-MIC-01','Luis A.','2025-12-05','2025-12-06','cerrada',1,30205,32114,1909),(28,'52',3,'2025-12-05-42',NULL,3,'lupe','SQ-MIC-01','Luis A.','2025-12-05','2025-12-06','cerrada',1,416940,419094,2154),(29,'52',5,'2025-12-06-03',NULL,4,'Luis Angel','SQ-MIC-01','Luis A.','2025-12-06','2025-12-06','cerrada',1,32114,41763,9649),(30,'52',3,'2025-12-06-42',NULL,3,'Luis Angel','SQ-MIC-01','Luis A.','2025-12-06','2025-12-06','cerrada',1,419094,427983,8889);
/*!40000 ALTER TABLE `ordenes_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piezas`
--

DROP TABLE IF EXISTS `piezas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `piezas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piezas`
--

LOCK TABLES `piezas` WRITE;
/*!40000 ALTER TABLE `piezas` DISABLE KEYS */;
INSERT INTO `piezas` VALUES (1,'000','Hamilton','Mezcla','Mezcla 70-30 Especial','2025-11-24 21:20:19'),(2,'438','Cople Estrella','Mezclado','Mezcla Especial 70/30','2025-11-24 22:00:14'),(3,'444','LIMITER','Mezcla','FC-0208','2025-11-25 15:02:52'),(4,'469','ENGRANE','Mezcla','Mezcla Especial 70/30','2025-11-25 15:34:27'),(5,'440','DOWEL PIN','MEZCLA','FC-0508','2025-11-25 15:51:31'),(6,'431','OSTER GRANDE','MEZCLA','Mezcla 70-30 premix','2025-11-25 16:00:06'),(7,'430','OSTER CHICO','MEZCLA','Mezcla Especial 70/30','2025-11-25 16:07:24'),(8,'612','LOAD LIMITER','MEZCLA','FC-0208','2025-11-25 16:15:46'),(9,'432','COPLE AMAZONAS','MEZCLA','Mezcla Especial 70/30','2025-11-25 16:22:17'),(10,'437','Cople whirpool','MEZCLA','FC-0208','2025-11-25 16:33:13'),(11,'441','CRUZETA','MEZCLA','Mezcla Especial 70/30','2025-11-25 16:39:44'),(12,'433','COPLE OLIMPIA','MEZCLA','AHC100','2025-11-25 16:45:24'),(13,'445','STRUCTURAL DUST COVER','MEZCLA','FC-0208','2025-11-25 16:53:32'),(14,'0432','CHUMACERA DE BRONCE 1\"','MEZCLA','BRONCE','2025-11-25 18:16:12'),(15,'461','PIEZA DE MOLETEADO','MEZCLA','F000208','2025-11-25 18:22:41'),(16,'442','BUJE DE HIERRO','MEZCLA','FLNC ESPECIAL','2025-11-25 19:12:20');
/*!40000 ALTER TABLE `piezas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prensas`
--

DROP TABLE IF EXISTS `prensas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prensas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prensas`
--

LOCK TABLES `prensas` WRITE;
/*!40000 ALTER TABLE `prensas` DISABLE KEYS */;
INSERT INTO `prensas` VALUES (1,'P01','Editar Descripción','2025-11-24 20:53:15'),(2,'P02','Editar Descripción','2025-11-24 20:53:58'),(3,'P03','Editar Descripción','2025-11-24 20:54:10'),(4,'P04','Editar Descripción','2025-11-24 20:54:17'),(5,'P05','Editar Descripción','2025-11-24 20:54:23'),(6,'CALIBRADORA 03','DOWELL PIN','2025-11-24 21:41:01');
/*!40000 ALTER TABLE `prensas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prensas_habilitadas`
--

DROP TABLE IF EXISTS `prensas_habilitadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prensas_habilitadas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `prensa_id` int(11) NOT NULL,
  `pieza_id` int(11) NOT NULL,
  `habilitado` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_dia_prensa` (`orden_id`,`fecha`,`prensa_id`),
  KEY `prensa_id` (`prensa_id`),
  KEY `pieza_id` (`pieza_id`),
  CONSTRAINT `prensas_habilitadas_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes_produccion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prensas_habilitadas_ibfk_2` FOREIGN KEY (`prensa_id`) REFERENCES `prensas` (`id`),
  CONSTRAINT `prensas_habilitadas_ibfk_3` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prensas_habilitadas`
--

LOCK TABLES `prensas_habilitadas` WRITE;
/*!40000 ALTER TABLE `prensas_habilitadas` DISABLE KEYS */;
INSERT INTO `prensas_habilitadas` VALUES (1,1,'2025-11-27',3,3,0),(2,2,'2025-11-27',4,8,0),(3,3,'2025-11-27',1,3,0),(4,4,'2025-11-28',3,3,0),(5,5,'2025-11-28',4,8,0),(6,6,'2025-11-29',3,3,0),(8,8,'2025-11-29',4,8,0),(9,9,'2025-12-01',3,3,0),(10,10,'2025-12-01',4,8,0),(11,11,'2025-12-02',3,3,0),(12,12,'2025-12-02',3,3,0),(13,13,'2025-12-03',3,3,0),(15,15,'2025-12-03',3,3,0),(17,17,'2025-12-03',3,3,0),(18,18,'2025-12-04',3,3,0),(19,19,'2025-12-04',3,3,0),(21,21,'2025-12-04',3,3,0),(22,22,'2025-12-04',4,5,0),(23,23,'2025-12-05',3,3,0),(24,24,'2025-12-05',4,5,0),(25,25,'2025-12-05',3,3,0),(26,26,'2025-12-05',4,5,0),(27,27,'2025-12-05',4,5,0),(28,28,'2025-12-05',3,3,0),(29,29,'2025-12-06',4,5,0),(30,30,'2025-12-06',3,3,0);
/*!40000 ALTER TABLE `prensas_habilitadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rendimientos`
--

DROP TABLE IF EXISTS `rendimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rendimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pieza_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `esperado` int(11) NOT NULL,
  `producido` int(11) DEFAULT 0,
  `rendimiento` decimal(5,2) GENERATED ALWAYS AS (case when `esperado` > 0 then `producido` / `esperado` * 100 else 0 end) STORED,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `orden_id` int(11) DEFAULT NULL,
  `numero_lote` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pieza_id` (`pieza_id`),
  KEY `orden_id` (`orden_id`),
  KEY `numero_lote` (`numero_lote`),
  CONSTRAINT `rendimientos_ibfk_1` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rendimientos`
--

LOCK TABLES `rendimientos` WRITE;
/*!40000 ALTER TABLE `rendimientos` DISABLE KEYS */;
INSERT INTO `rendimientos` VALUES (1,3,'2025-11-27',8000,8272,103.40,'2025-11-28 05:02:17',1,NULL),(2,8,'2025-11-27',10400,5296,50.92,'2025-11-28 05:02:40',2,NULL),(3,3,'2025-11-27',8000,8682,108.53,'2025-11-28 05:07:07',3,NULL),(4,3,'2025-11-28',8000,8920,111.50,'2025-11-29 05:00:58',4,NULL),(5,8,'2025-11-28',10400,8074,77.63,'2025-11-29 05:01:24',5,NULL),(6,3,'2025-11-29',8000,6571,82.14,'2025-11-30 02:38:24',6,NULL),(7,8,'2025-11-29',8000,6201,77.51,'2025-11-30 02:38:53',8,NULL),(8,3,'2025-12-01',8000,5025,62.81,'2025-12-02 04:55:08',9,NULL),(9,8,'2025-12-01',8000,4494,56.18,'2025-12-02 04:55:24',10,NULL),(10,3,'2025-12-02',8000,6431,80.39,'2025-12-03 05:02:10',11,NULL),(11,3,'2025-12-03',8000,6480,81.00,'2025-12-03 06:06:57',12,NULL),(12,3,'2025-12-03',8000,8797,109.96,'2025-12-03 14:07:29',13,NULL),(13,3,'2025-12-03',8000,9171,114.64,'2025-12-03 21:57:03',15,NULL),(14,3,'2025-12-04',8000,10030,125.38,'2025-12-04 06:20:36',17,NULL),(16,3,'2025-12-04',8000,7831,97.89,'2025-12-04 14:19:37',18,NULL),(17,3,'2025-12-04',8000,6473,80.91,'2025-12-04 21:59:55',19,NULL),(18,3,'2025-12-05',8000,10057,125.71,'2025-12-05 06:16:46',21,NULL),(19,5,'2025-12-05',8000,7439,92.99,'2025-12-05 06:17:15',22,NULL),(20,3,'2025-12-05',8000,9176,114.70,'2025-12-05 14:07:04',23,NULL),(21,5,'2025-12-05',8000,9173,114.66,'2025-12-05 14:07:33',24,NULL),(22,5,'2025-12-05',16000,13593,84.96,'2025-12-06 04:18:01',26,NULL),(23,3,'2025-12-05',16000,17523,109.52,'2025-12-06 04:18:18',25,NULL),(24,3,'2025-12-06',2000,2154,107.70,'2025-12-06 06:02:28',28,NULL),(25,5,'2025-12-06',2000,1909,95.45,'2025-12-06 06:02:47',27,NULL),(26,5,'2025-12-06',8000,9649,120.61,'2025-12-06 18:39:51',29,NULL),(27,3,'2025-12-06',8000,8889,111.11,'2025-12-06 18:40:08',30,NULL);
/*!40000 ALTER TABLE `rendimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','operador') NOT NULL,
  `creado_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','$2y$10$HlHnBt6aWyXpPlb6r2WGE.JZy1jhjyzsqc6YaqzCPu7s4.3Q24azq','admin','2025-11-24 20:38:21');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `valores_hora`
--

DROP TABLE IF EXISTS `valores_hora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `valores_hora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `captura_id` int(11) NOT NULL,
  `atributo_pieza_id` int(11) NOT NULL,
  `valor` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `captura_id` (`captura_id`),
  KEY `atributo_pieza_id` (`atributo_pieza_id`),
  CONSTRAINT `valores_hora_ibfk_1` FOREIGN KEY (`captura_id`) REFERENCES `capturas_hora` (`id`) ON DELETE CASCADE,
  CONSTRAINT `valores_hora_ibfk_2` FOREIGN KEY (`atributo_pieza_id`) REFERENCES `atributos_pieza` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=761 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `valores_hora`
--

LOCK TABLES `valores_hora` WRITE;
/*!40000 ALTER TABLE `valores_hora` DISABLE KEYS */;
INSERT INTO `valores_hora` VALUES (1,2,15,'1.210'),(2,2,16,'2.570'),(3,2,17,'7.480'),(4,2,18,'11.968'),(5,2,19,'6.722'),(6,4,44,'0.670'),(7,4,45,'1.560'),(8,4,46,'8.640'),(9,4,47,'12.701'),(10,4,48,'6.7'),(11,3,15,'1.200'),(12,3,16,'2.580'),(13,3,17,'7.480'),(14,3,18,'11.986'),(15,3,19,'6.667'),(16,6,15,'1.210'),(17,6,16,'2.520'),(18,6,17,'7.490'),(19,6,18,'11.975'),(20,6,19,'6.722'),(21,5,44,'0.670'),(22,5,45,'1.560'),(23,5,46,'8.640'),(24,5,47,'12.704'),(25,5,48,'6.700'),(26,15,44,'0.670'),(27,15,45,'1.560'),(28,15,46,'8.640'),(29,15,47,'12.710'),(30,15,48,'6.700'),(31,7,15,'1.200'),(32,7,16,'2.570'),(33,7,17,'7.480'),(34,7,18,'11.980'),(35,7,19,'6.667'),(36,8,15,'1.210'),(37,8,16,'2.560'),(38,8,17,'7.480'),(39,8,18,'11.971'),(40,8,19,'6.722'),(41,16,44,'0.660'),(42,16,45,'1.560'),(43,16,46,'8.640'),(44,16,47,'12.730'),(45,16,48,'6.600'),(46,9,15,'1.190'),(47,9,16,'2.540'),(48,9,17,'7.480'),(49,9,18,'11.976'),(50,9,19,'6.611'),(51,17,44,'0.680'),(52,17,45,'1.570'),(53,17,46,'8.630'),(54,17,47,'12.710'),(55,17,48,'6.800'),(56,10,15,'1.200'),(57,10,16,'2.570'),(58,10,17,'7.490'),(59,10,18,'11.970'),(60,10,19,'6.667'),(61,18,44,'0.670'),(62,18,45,'1.560'),(63,18,46,'8.630'),(64,18,47,'12.741'),(65,18,48,'6.700'),(66,11,15,'1.190'),(67,11,16,'2.560'),(68,11,17,'7.480'),(69,11,18,'11.980'),(70,11,19,'6.611'),(71,19,44,'0.680'),(72,19,45,'1.560'),(73,19,46,'8.630'),(74,19,47,'12.718'),(75,19,48,'6.800'),(76,12,15,'1.210'),(77,12,16,'2.560'),(78,12,17,'7.480'),(79,12,18,'11.982'),(80,12,19,'6.722'),(81,20,44,'0.680'),(82,20,45,'1.570'),(83,20,46,'8.630'),(84,20,47,'12.714'),(85,20,48,'6.800'),(86,13,15,'1.210'),(87,13,16,'2.570'),(88,13,17,'7.480'),(89,13,18,'11.979'),(90,13,19,'6.722'),(91,21,44,'0.680'),(92,21,45,'1.570'),(93,21,46,'8.630'),(94,21,47,'12.706'),(95,21,48,'6.800'),(96,14,15,'1.210'),(97,14,16,'2.580'),(98,14,17,'7.480'),(99,14,18,'11.973'),(100,14,19,'6.722'),(101,22,44,'0.680'),(102,22,45,'1.570'),(103,22,46,'8.640'),(104,22,47,'12.709'),(105,22,48,'6.800'),(106,39,44,'0.690'),(107,39,45,'1.570'),(108,39,46,'8.630'),(109,39,47,'12.720'),(110,39,48,'6.900'),(111,23,15,'1.190'),(112,23,16,'2.567'),(113,23,17,'7.480'),(114,23,18,'11.970'),(115,23,19,'6.611'),(116,24,15,'1.200'),(117,24,16,'2.550'),(118,24,17,'7.480'),(119,24,18,'11.972'),(120,24,19,'6.667'),(121,40,44,'0.670'),(122,40,45,'1.570'),(123,40,46,'8.630'),(124,40,47,'12.710'),(125,40,48,'6.700'),(126,25,15,'1.190'),(127,25,16,'2.560'),(128,25,17,'7.480'),(129,25,18,'11.980'),(130,25,19,'6.611'),(131,41,44,'0.680'),(132,41,45,'1.570'),(133,41,46,'8.610'),(134,41,47,'12.720'),(135,41,48,'6.800'),(136,26,15,'1.200'),(137,26,16,'2.550'),(138,26,17,'7.480'),(139,26,18,'11.980'),(140,26,19,'6.667'),(141,42,44,'0.680'),(142,42,45,'1.550'),(143,42,46,'8.650'),(144,42,47,'12.710'),(145,42,48,'6.800'),(146,43,44,'0.678'),(147,43,45,'1.560'),(148,43,46,'8.660'),(149,43,47,'12.730'),(150,43,48,'6.780'),(151,27,15,'1.210'),(152,27,16,'2.560'),(153,27,17,'7.480'),(154,27,18,'11.990'),(155,27,19,'6.722'),(156,47,15,'1.200'),(157,47,16,'2.550'),(158,47,17,'7.490'),(159,47,18,'11.979'),(160,47,19,'6.667'),(161,52,44,'0.680'),(162,52,45,'1.590'),(163,52,46,'8.630'),(164,52,47,'12.703'),(165,52,48,'6.800'),(166,49,15,'1.210'),(167,49,16,'2.550'),(168,49,17,'7.480'),(169,49,18,'11.970'),(170,49,19,'6.722'),(171,54,44,'0.680'),(172,54,45,'1.560'),(173,54,46,'8.630'),(174,54,47,'12.718'),(175,54,48,'6.800'),(176,50,15,'1.210'),(177,50,16,'2.560'),(178,50,17,'7.480'),(179,50,18,'11.984'),(180,50,19,'6.722'),(181,55,44,'0.680'),(182,55,45,'1.570'),(183,55,46,'8.630'),(184,55,47,'12.722'),(185,55,48,'6.800'),(186,51,15,'1.200'),(187,51,16,'2.540'),(188,51,17,'7.490'),(189,51,18,'11.979'),(190,51,19,'6.667'),(191,56,44,'0.670'),(192,56,45,'1.550'),(193,56,46,'8.640'),(194,56,47,'12.720'),(195,56,48,'6.700'),(196,57,15,'1.199'),(197,57,16,'2.512'),(198,57,17,'7.490'),(199,57,18,'11.969'),(200,57,19,'6.661'),(201,58,15,'1.190'),(202,58,16,'2.520'),(203,58,17,'7.491'),(204,58,18,'11.991'),(205,58,19,'6.611'),(206,59,15,'1.200'),(207,59,16,'2.520'),(208,59,17,'7.490'),(209,59,18,'12.005'),(210,59,19,'6.667'),(211,60,15,'1.199'),(212,60,16,'2.530'),(213,60,17,'7.480'),(214,60,18,'11.980'),(215,60,19,'6.661'),(216,61,15,'1.191'),(217,61,16,'2.540'),(218,61,17,'7.490'),(219,61,18,'11.981'),(220,61,19,'6.617'),(221,62,15,'1.200'),(222,62,16,'2.520'),(223,62,17,'7.480'),(224,62,18,'11.990'),(225,62,19,'6.667'),(226,63,15,'1.200'),(227,63,16,'2.540'),(228,63,17,'7.490'),(229,63,18,'11.960'),(230,63,19,'6.667'),(231,64,15,'1.200'),(232,64,16,'2.520'),(233,64,17,'7.490'),(234,64,18,'11.978'),(235,64,19,'6.667'),(236,65,15,'1.200'),(237,65,16,'2.530'),(238,65,17,'7.480'),(239,65,18,'11.965'),(240,65,19,'6.667'),(241,69,15,'1.210'),(242,69,16,'2.520'),(243,69,17,'7.480'),(244,69,18,'11.980'),(245,69,19,'6.722'),(246,70,15,'1.210'),(247,70,16,'2.551'),(248,70,17,'7.480'),(249,70,18,'11.990'),(250,70,19,'6.722'),(251,71,15,'1.190'),(252,71,16,'2.530'),(253,71,17,'7.480'),(254,71,18,'11.980'),(255,71,19,'6.611'),(256,72,15,'1.200'),(257,72,16,'2.520'),(258,72,17,'7.480'),(259,72,18,'12.000'),(260,72,19,'6.667'),(261,73,15,'1.210'),(262,73,16,'2.550'),(263,73,17,'7.480'),(264,73,18,'11.980'),(265,73,19,'6.722'),(266,74,15,'1.190'),(267,74,16,'2.501'),(268,74,17,'7.480'),(269,74,18,'11.970'),(270,74,19,'6.611'),(271,75,15,'1.190'),(272,75,16,'2.510'),(273,75,17,'7.480'),(274,75,18,'11.980'),(275,75,19,'6.611'),(276,77,15,'1.190'),(277,77,16,'2.530'),(278,77,17,'7.480'),(279,77,18,'11.960'),(280,77,19,'6.611'),(281,78,15,'1.199'),(282,78,16,'2.560'),(283,78,17,'7.480'),(284,78,18,'11.980'),(285,78,19,'6.661'),(286,87,15,'1.200'),(287,87,16,'2.560'),(288,87,17,'7.480'),(289,87,18,'11.965'),(290,87,19,'6.667'),(291,88,15,'1.190'),(292,88,16,'2.580'),(293,88,17,'7.480'),(294,88,18,'11.985'),(295,88,19,'6.611'),(296,89,15,'1.210'),(297,89,16,'2.560'),(298,89,17,'7.480'),(299,89,18,'11.986'),(300,89,19,'6.722'),(301,90,15,'1.210'),(302,90,16,'2.570'),(303,90,17,'7.490'),(304,90,18,'11.968'),(305,90,19,'6.722'),(306,91,15,'1.190'),(307,91,16,'2.500'),(308,91,17,'7.480'),(309,91,18,'11.976'),(310,91,19,'6.611'),(311,92,15,'1.190'),(312,92,16,'2.500'),(313,92,17,'7.490'),(314,92,18,'11.963'),(315,92,19,'6.611'),(316,93,15,'1.210'),(317,93,16,'2.520'),(318,93,17,'7.480'),(319,93,18,'11.970'),(320,93,19,'6.722'),(321,94,15,'1.190'),(322,94,16,'2.530'),(323,94,17,'7.490'),(324,94,18,'11.980'),(325,94,19,'6.611'),(326,95,15,'1.190'),(327,95,16,'2.520'),(328,95,17,'7.480'),(329,95,18,'11.962'),(330,95,19,'6.611'),(331,96,15,'1.210'),(332,96,16,'2.520'),(333,96,17,'7.480'),(334,96,18,'11.963'),(335,96,19,'6.722'),(336,97,15,'1.200'),(337,97,16,'2.520'),(338,97,17,'7.480'),(339,97,18,'11.968'),(340,97,19,'6.667'),(341,98,15,'1.190'),(342,98,16,'2.520'),(343,98,17,'7.490'),(344,98,18,'11.975'),(345,98,19,'6.611'),(346,99,15,'1.190'),(347,99,16,'2.510'),(348,99,17,'7.480'),(349,99,18,'11.976'),(350,99,19,'6.611'),(351,101,15,'1.200'),(352,101,16,'2.556'),(353,101,17,'7.500'),(354,101,18,'11.961'),(355,101,19,'6.667'),(356,102,15,'1.210'),(357,102,16,'2.540'),(358,102,17,'7.489'),(359,102,18,'11.998'),(360,102,19,'6.722'),(361,103,15,'1.210'),(362,103,16,'2.560'),(363,103,17,'7.480'),(364,103,18,'11.980'),(365,103,19,'6.722'),(366,104,15,'1.210'),(367,104,16,'2.560'),(368,104,17,'7.480'),(369,104,18,'11.990'),(370,104,19,'6.722'),(371,105,15,'1.210'),(372,105,16,'2.550'),(373,105,17,'7.480'),(374,105,18,'11.980'),(375,105,19,'6.722'),(376,106,15,'1.210'),(377,106,16,'2.570'),(378,106,17,'7.480'),(379,106,18,'11.990'),(380,106,19,'6.722'),(381,107,15,'1.190'),(382,107,16,'2.510'),(383,107,17,'7.480'),(384,107,18,'11.980'),(385,107,19,'6.611'),(386,108,15,'1.210'),(387,108,16,'2.550'),(388,108,17,'7.480'),(389,108,18,'11.980'),(390,108,19,'6.722'),(391,109,15,'1.210'),(392,109,16,'2.520'),(393,109,17,'7.480'),(394,109,18,'11.962'),(395,109,19,'6.722'),(396,110,15,'1.200'),(397,110,16,'2.560'),(398,110,17,'7.480'),(399,110,18,'11.986'),(400,110,19,'6.667'),(401,111,15,'1.200'),(402,111,16,'2.530'),(403,111,17,'7.480'),(404,111,18,'11.969'),(405,111,19,'6.667'),(406,112,15,'1.190'),(407,112,16,'2.530'),(408,112,17,'7.490'),(409,112,18,'11.962'),(410,112,19,'6.611'),(411,113,15,'1.190'),(412,113,16,'2.520'),(413,113,17,'7.480'),(414,113,18,'11.962'),(415,113,19,'6.611'),(416,114,15,'1.210'),(417,114,16,'2.550'),(418,114,17,'7.480'),(419,114,18,'11.984'),(420,114,19,'6.722'),(421,116,15,'1.200'),(422,116,16,'2.520'),(423,116,17,'7.480'),(424,116,18,'11.975'),(425,116,19,'6.667'),(431,117,15,'1.210'),(432,117,16,'2.560'),(433,117,17,'7.480'),(434,117,18,'11.976'),(435,117,19,'6.722'),(436,118,15,'1.200'),(437,118,16,'2.550'),(438,118,17,'7.490'),(439,118,18,'11.981'),(440,118,19,'6.667'),(441,126,15,'1.210'),(442,126,16,'2.560'),(443,126,17,'7.480'),(444,126,18,'11.979'),(445,126,19,'6.722'),(446,127,15,'1.200'),(447,127,16,'2.560'),(448,127,17,'7.480'),(449,127,18,'11.976'),(450,127,19,'6.667'),(451,128,15,'1.210'),(452,128,16,'2.580'),(453,128,17,'7.490'),(454,128,18,'11.980'),(455,128,19,'6.722'),(456,134,25,'2.030'),(457,134,26,'7.820'),(458,134,27,'6.980'),(459,134,28,'10.070'),(460,134,29,'0.303'),(461,135,25,'2.030'),(462,135,26,'7.810'),(463,135,27,'6.980'),(464,135,28,'10.070'),(465,135,29,'0.303'),(466,129,15,'1.210'),(467,129,16,'2.560'),(468,129,17,'7.480'),(469,129,18,'11.975'),(470,129,19,'6.722'),(471,130,15,'1.200'),(472,130,16,'2.560'),(473,130,17,'7.490'),(474,130,18,'11.981'),(475,130,19,'6.667'),(476,136,25,'2.030'),(477,136,26,'7.810'),(478,136,27,'6.980'),(479,136,28,'10.080'),(480,136,29,'0.303'),(481,137,25,'2.020'),(482,137,26,'7.840'),(483,137,27,'6.980'),(484,137,28,'10.085'),(485,137,29,'0.302'),(486,131,15,'1.210'),(487,131,16,'2.560'),(488,131,17,'7.480'),(489,131,18,'11.986'),(490,131,19,'6.722'),(491,132,15,'1.210'),(492,132,16,'2.550'),(493,132,17,'7.480'),(494,132,18,'11.990'),(495,132,19,'6.722'),(496,138,25,'2.010'),(497,138,26,'7.850'),(498,138,27,'6.980'),(499,138,28,'10.080'),(500,138,29,'0.300'),(501,133,15,'1.210'),(502,133,16,'2.550'),(503,133,17,'7.480'),(504,133,18,'11.980'),(505,133,19,'6.722'),(506,140,15,'1.200'),(507,140,16,'2.550'),(508,140,17,'7.480'),(509,140,18,'11.980'),(510,140,19,'6.667'),(511,148,25,'2.010'),(512,148,26,'7.850'),(513,148,27,'6.990'),(514,148,28,'10.090'),(515,148,29,'0.300'),(516,149,25,'2.020'),(517,149,26,'7.840'),(518,149,27,'6.981'),(519,149,28,'10.081'),(520,149,29,'0.302'),(521,141,15,'1.201'),(522,141,16,'2.541'),(523,141,17,'7.491'),(524,141,18,'11.989'),(525,141,19,'6.672'),(526,142,15,'1.190'),(527,142,16,'2.510'),(528,142,17,'7.480'),(529,142,18,'11.980'),(530,142,19,'6.611'),(531,150,25,'2.020'),(532,150,26,'7.850'),(533,150,27,'6.990'),(534,150,28,'10.090'),(535,150,29,'0.302'),(536,151,25,'2.020'),(537,151,26,'7.860'),(538,151,27,'6.990'),(539,151,28,'10.090'),(540,151,29,'0.302'),(541,143,15,'1.190'),(542,143,16,'2.560'),(543,143,17,'7.480'),(544,143,18,'11.970'),(545,143,19,'6.611'),(546,144,15,'1.210'),(547,144,16,'2.570'),(548,144,17,'7.480'),(549,144,18,'11.980'),(550,144,19,'6.722'),(551,152,25,'2.020'),(552,152,26,'7.850'),(553,152,27,'6.990'),(554,152,28,'10.090'),(555,152,29,'0.302'),(556,153,25,'2.020'),(557,153,26,'7.840'),(558,153,27,'6.990'),(559,153,28,'10.090'),(560,153,29,'0.302'),(561,145,15,'1.210'),(562,145,16,'2.550'),(563,145,17,'7.480'),(564,145,18,'11.980'),(565,145,19,'6.722'),(566,146,15,'1.190'),(567,146,16,'2.550'),(568,146,17,'7.480'),(569,146,18,'11.968'),(570,146,19,'6.611'),(571,154,25,'2.010'),(572,154,26,'7.830'),(573,154,27,'6.980'),(574,154,28,'10.080'),(575,154,29,'0.300'),(576,155,25,'2.030'),(577,155,26,'7.870'),(578,155,27,'6.990'),(579,155,28,'10.075'),(580,155,29,'0.303'),(581,147,15,'1.190'),(582,147,16,'2.530'),(583,147,17,'7.490'),(584,147,18,'11.972'),(585,147,19,'6.611'),(586,164,25,'2.010'),(587,164,26,'7.830'),(588,164,27,'6.980'),(589,164,28,'10.080'),(590,164,29,'0.300'),(591,156,15,'1.200'),(592,156,16,'2.550'),(593,156,17,'7.480'),(594,156,18,'11.983'),(595,156,19,'6.667'),(596,157,15,'1.190'),(597,157,16,'2.560'),(598,157,17,'7.490'),(599,157,18,'11.973'),(600,157,19,'6.611'),(601,165,25,'2.030'),(602,165,26,'7.850'),(603,165,27,'6.990'),(604,165,28,'10.032'),(605,165,29,'0.303'),(606,166,25,'2.020'),(607,166,26,'7.840'),(608,166,27,'7.010'),(609,166,28,'10.027'),(610,166,29,'0.302'),(611,158,15,'1.200'),(612,158,16,'2.550'),(613,158,17,'7.490'),(614,158,18,'11.976'),(615,158,19,'6.667'),(616,159,15,'1.210'),(617,159,16,'2.570'),(618,159,17,'7.480'),(619,159,18,'11.961'),(620,159,19,'6.722'),(621,167,25,'2.020'),(622,167,26,'7.880'),(623,167,27,'7.000'),(624,167,28,'10.027'),(625,167,29,'0.302'),(626,168,25,'2.020'),(627,168,26,'7.820'),(628,168,27,'7.000'),(629,168,28,'10.035'),(630,168,29,'0.302'),(631,160,15,'1.200'),(632,160,16,'2.560'),(633,160,17,'7.490'),(634,160,18,'11.968'),(635,160,19,'6.667'),(636,161,15,'1.190'),(637,161,16,'2.560'),(638,161,17,'7.490'),(639,161,18,'11.989'),(640,161,19,'6.611'),(641,169,25,'2.010'),(642,169,26,'7.830'),(643,169,27,'6.980'),(644,169,28,'10.080'),(645,169,29,'0.300'),(646,162,15,'1.210'),(647,162,16,'2.550'),(648,162,17,'7.480'),(649,162,18,'12.010'),(650,162,19,'6.722'),(651,170,25,'2.020'),(652,170,26,'7.810'),(653,170,27,'6.970'),(654,170,28,'10.070'),(655,170,29,'0.302'),(656,171,25,'2.010'),(657,171,26,'7.790'),(658,171,27,'7.000'),(659,171,28,'10.080'),(660,171,29,'0.300'),(661,163,15,'1.210'),(662,163,16,'2.570'),(663,163,17,'7.480'),(664,163,18,'11.980'),(665,163,19,'6.722'),(666,174,15,'1.210'),(667,174,16,'2.554'),(668,174,17,'7.490'),(669,174,18,'11.960'),(670,174,19,'6.722'),(671,172,25,'2.030'),(672,172,26,'7.840'),(673,172,27,'6.980'),(674,172,28,'10.070'),(675,172,29,'0.303'),(676,173,25,'2.030'),(677,173,26,'7.880'),(678,173,27,'6.960'),(679,173,28,'10.080'),(680,173,29,'0.303'),(681,184,15,'1.210'),(682,184,16,'2.530'),(683,184,17,'7.500'),(684,184,18,'11.960'),(685,184,19,'6.722'),(686,176,25,'2.020'),(687,176,26,'7.840'),(688,176,27,'7.010'),(689,176,28,'10.070'),(690,176,29,'0.302'),(691,177,25,'2.020'),(692,177,26,'7.860'),(693,177,27,'6.990'),(694,177,28,'10.080'),(695,177,29,'0.302'),(696,185,15,'1.210'),(697,185,16,'2.580'),(698,185,17,'7.480'),(699,185,18,'11.960'),(700,185,19,'6.722'),(701,186,15,'1.210'),(702,186,16,'2.560'),(703,186,17,'7.487'),(704,186,18,'11.960'),(705,186,19,'6.722'),(706,178,25,'2.020'),(707,178,26,'7.850'),(708,178,27,'6.990'),(709,178,28,'10.070'),(710,178,29,'0.302'),(711,179,25,'2.020'),(712,179,26,'7.831'),(713,179,27,'6.980'),(714,179,28,'10.070'),(715,179,29,'0.302'),(716,187,15,'1.210'),(717,187,16,'2.539'),(718,187,17,'7.489'),(719,187,18,'11.989'),(720,187,19,'6.722'),(721,188,15,'1.200'),(722,188,16,'2.540'),(723,188,17,'7.490'),(724,188,18,'11.990'),(725,188,19,'6.667'),(726,180,25,'2.010'),(727,180,26,'7.830'),(728,180,27,'6.980'),(729,180,28,'10.080'),(730,180,29,'0.300'),(731,181,25,'2.010'),(732,181,26,'7.830'),(733,181,27,'6.980'),(734,181,28,'10.080'),(735,181,29,'0.300'),(736,189,15,'1.200'),(737,189,16,'2.540'),(738,189,17,'7.490'),(739,189,18,'11.990'),(740,189,19,'6.667'),(741,190,15,'1.200'),(742,190,16,'2.530'),(743,190,17,'7.490'),(744,190,18,'11.998'),(745,190,19,'6.667'),(746,182,25,'2.010'),(747,182,26,'7.790'),(748,182,27,'6.980'),(749,182,28,'10.085'),(750,182,29,'0.300'),(751,183,25,'2.010'),(752,183,26,'7.830'),(753,183,27,'6.980'),(754,183,28,'10.080'),(755,183,29,'0.300'),(756,191,15,'1.200'),(757,191,16,'2.540'),(758,191,17,'7.490'),(759,191,18,'11.990'),(760,191,19,'6.667');
/*!40000 ALTER TABLE `valores_hora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-06 17:43:38
