-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: erp
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atributos_pieza`
--

DROP TABLE IF EXISTS `atributos_pieza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atributos_pieza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pieza_id` int(11) NOT NULL,
  `nombre_atributo` varchar(50) NOT NULL,
  `unidad` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pieza_id` (`pieza_id`),
  CONSTRAINT `atributos_pieza_ibfk_1` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atributos_pieza`
--

LOCK TABLES `atributos_pieza` WRITE;
/*!40000 ALTER TABLE `atributos_pieza` DISABLE KEYS */;
/*!40000 ALTER TABLE `atributos_pieza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capturas_hora`
--

DROP TABLE IF EXISTS `capturas_hora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capturas_hora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `prensa_id` int(11) NOT NULL,
  `pieza_id` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `observaciones_op` text DEFAULT NULL,
  `firma_operador` varchar(100) DEFAULT NULL,
  `estado` enum('pendiente','cerrada') DEFAULT 'pendiente',
  PRIMARY KEY (`id`),
  KEY `orden_id` (`orden_id`),
  KEY `prensa_id` (`prensa_id`),
  KEY `pieza_id` (`pieza_id`),
  CONSTRAINT `capturas_hora_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes_produccion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `capturas_hora_ibfk_2` FOREIGN KEY (`prensa_id`) REFERENCES `prensas` (`id`),
  CONSTRAINT `capturas_hora_ibfk_3` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capturas_hora`
--

LOCK TABLES `capturas_hora` WRITE;
/*!40000 ALTER TABLE `capturas_hora` DISABLE KEYS */;
/*!40000 ALTER TABLE `capturas_hora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes_produccion`
--

DROP TABLE IF EXISTS `ordenes_produccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordenes_produccion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_orden` varchar(20) NOT NULL,
  `pieza_id` int(11) NOT NULL,
  `numero_lote` varchar(50) DEFAULT NULL,
  `cantidad_total_lote` int(11) DEFAULT NULL,
  `prensa_id` int(11) DEFAULT NULL,
  `operador_asignado` varchar(100) DEFAULT NULL,
  `equipo_asignado` varchar(100) DEFAULT NULL,
  `fecha_liberacion` date DEFAULT NULL,
  `firma_responsable` varchar(100) DEFAULT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_cierre` date DEFAULT NULL,
  `estado` enum('abierta','cerrada') DEFAULT 'abierta',
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pieza_id` (`pieza_id`),
  KEY `prensa_id` (`prensa_id`),
  KEY `admin_id` (`admin_id`),
  CONSTRAINT `ordenes_produccion_ibfk_1` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`),
  CONSTRAINT `ordenes_produccion_ibfk_2` FOREIGN KEY (`prensa_id`) REFERENCES `prensas` (`id`),
  CONSTRAINT `ordenes_produccion_ibfk_3` FOREIGN KEY (`admin_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes_produccion`
--

LOCK TABLES `ordenes_produccion` WRITE;
/*!40000 ALTER TABLE `ordenes_produccion` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordenes_produccion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `piezas`
--

DROP TABLE IF EXISTS `piezas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `piezas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `piezas`
--

LOCK TABLES `piezas` WRITE;
/*!40000 ALTER TABLE `piezas` DISABLE KEYS */;
/*!40000 ALTER TABLE `piezas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prensas`
--

DROP TABLE IF EXISTS `prensas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prensas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `creado_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prensas`
--

LOCK TABLES `prensas` WRITE;
/*!40000 ALTER TABLE `prensas` DISABLE KEYS */;
/*!40000 ALTER TABLE `prensas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prensas_habilitadas`
--

DROP TABLE IF EXISTS `prensas_habilitadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prensas_habilitadas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `prensa_id` int(11) NOT NULL,
  `pieza_id` int(11) NOT NULL,
  `habilitado` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_dia_prensa` (`orden_id`,`fecha`,`prensa_id`),
  KEY `prensa_id` (`prensa_id`),
  KEY `pieza_id` (`pieza_id`),
  CONSTRAINT `prensas_habilitadas_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes_produccion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prensas_habilitadas_ibfk_2` FOREIGN KEY (`prensa_id`) REFERENCES `prensas` (`id`),
  CONSTRAINT `prensas_habilitadas_ibfk_3` FOREIGN KEY (`pieza_id`) REFERENCES `piezas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prensas_habilitadas`
--

LOCK TABLES `prensas_habilitadas` WRITE;
/*!40000 ALTER TABLE `prensas_habilitadas` DISABLE KEYS */;
/*!40000 ALTER TABLE `prensas_habilitadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('admin','operador') NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `creado_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'admin','$2y$10$ap2/xfeayCsV2BUZfPZZqeIXab3iJOuloI5tfJyPEC7sNyKKy04aC','admin',NULL,'2025-10-09 15:19:11');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `valores_hora`
--

DROP TABLE IF EXISTS `valores_hora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `valores_hora` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `captura_id` int(11) NOT NULL,
  `atributo_pieza_id` int(11) NOT NULL,
  `valor` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `captura_id` (`captura_id`),
  KEY `atributo_pieza_id` (`atributo_pieza_id`),
  CONSTRAINT `valores_hora_ibfk_1` FOREIGN KEY (`captura_id`) REFERENCES `capturas_hora` (`id`) ON DELETE CASCADE,
  CONSTRAINT `valores_hora_ibfk_2` FOREIGN KEY (`atributo_pieza_id`) REFERENCES `atributos_pieza` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `valores_hora`
--

LOCK TABLES `valores_hora` WRITE;
/*!40000 ALTER TABLE `valores_hora` DISABLE KEYS */;
/*!40000 ALTER TABLE `valores_hora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-13  9:54:19
